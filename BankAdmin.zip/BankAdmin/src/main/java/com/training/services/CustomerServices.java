package com.training.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.bean.Account;
import com.training.bean.BankCustomer;
import com.training.bean.Transaction;
import com.training.repo.AccountRepo;
import com.training.repo.CustomerRepo;
import com.training.repo.TransactionRepo;

@Service
public class CustomerServices {
	@Autowired
	private CustomerRepo customerRepo;
	@Autowired
	private AccountRepo accountRepo;
	@Autowired
	private TransactionRepo transactionRepo;
	
	private List<Account> accounts;

	public Account amount(int accountId)
	{
		Optional<Account> opAccount = accountRepo.findById(accountId);
		if(opAccount.isPresent())
			return opAccount.get();
		return null;
	}
	
	public BankCustomer customerDetails(int custId)
	{
		Optional<BankCustomer> opCustomer = customerRepo.findById(custId);
		if(opCustomer.isPresent())
			return opCustomer.get();
		return null;
	}
	public Transaction addTransaction(Transaction transaction)
	{
		return transactionRepo.save(transaction);
		
	}

	public Account viewAccount(int accountId) {
		Optional<Account> opAccount = accountRepo.findById(accountId);
		if(opAccount.isPresent())
			return opAccount.get();
		return null;
	}
}
